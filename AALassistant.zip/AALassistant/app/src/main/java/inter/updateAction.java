package inter;

public interface updateAction {
    void onListFragmentInteraction(String address);

    void onShowProgress();

    void onHideProgress();
}