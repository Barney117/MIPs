package com.example.aal_assistant;

public class XYZ {

   // private double Y, Z;
    String X_data,Y_data, Z_data;;
    private String Time;


    /**
     * Constructor for a basic measurement.
     *
     * @param X_data    the x axis acceleration
     * @param Y_data    the y axis acceleration
     * @param Z_data    the z axis acceleration
   // * @param Time the time the measurement was taken
     */
    public XYZ(String X_data, String Y_data, String Z_data) {
//        this.X_data = X_data;
//        this.Y = Y_data;
//        this.Z = Z_data;
 //       this.Time = Time;
    }

    public void setX(String X_data) {
        this.X_data = X_data;
    }

    public void setY(String y) {
        this.Y_data = y;
    }

    public void setZ(String Z) {
        this.Z_data = Z;
    }

    /**
     * Returns the combined acceleration sqrt(x^2 + y^2 + z^2).
     *
     * @return the acceleration of all three axes combined
     */

    public double getCombined() {
        return 0.02;
        //return Math.sqrt(x * x + y * y + z * z);
    }

    public String getX() {
        return X_data;
    }

    public String getY() {
        return Y_data;
    }

    public String getZ() {
        return Z_data;
    }

    public String getTime() {
        return Time;
    }
}
