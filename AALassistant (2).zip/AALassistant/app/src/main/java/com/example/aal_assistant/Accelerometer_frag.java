package com.example.aal_assistant;

import android.support.v4.app.Fragment;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import java.text.DateFormat;
import java.util.ArrayList;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

//public class Accelerometer_frag extends Fragment implements View.OnClickListener{
public class Accelerometer_frag extends Fragment {
    private static final String TAG = "MainActivity";

static  int i=0;
    private DatabaseReference databaseReference;
    locationCon mloc = new locationCon();
    private static final String ARG_ADDRESS = "address";
    private String mAddress ;

 //  private boolean mIsRecording = false;
    private boolean mIsRecording = true;
    private ArrayList<XYZ> mRecording;
    private inter.updateAction mListener;
    private Calendar previousRead, recordingStart;
private static double L1,L2;
private String locAddress;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothGatt mGatt;
    private BluetoothGattService mMovService;
    private BluetoothGattCharacteristic mRead, mEnable, mPeriod;

    private TextView mXAxis, mYAxis, mZAxis, lat, lon, textAddress;
    private Button mStart, mStop, mExport;


    /**
     * Mandatory empty constructor.
     */
    public Accelerometer_frag() {
    }

    /**
     * Returns a new instance of this Fragment.
     *
     * @param address the MAC address of the device to connect
     * @return A new instance of {@link Accelerometer_frag}
     */
    public static Accelerometer_frag newInstance(String address) {
        Accelerometer_frag fragment = new Accelerometer_frag();
        Bundle args = new Bundle();
        args.putString(ARG_ADDRESS, address);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mAddress = getArguments().getString(ARG_ADDRESS);
        }
        databaseReference = FirebaseDatabase.getInstance().getReference();
       // location_service;
        // initialize bluetooth manager & adapter
        BluetoothManager manager = (BluetoothManager) getActivity().getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = manager.getAdapter();
    }

    @Override
    public void onResume() {
        super.onResume();
        connectDevice(mAddress);
    }

    @Override
    public void onPause() {
        deviceDisconnected();
        super.onPause();
    }

    /**
     * Creates a GATT connection to the given device.
     *
     * String containing the address of the device
     */
    private void connectDevice(String address) {
        if (!mBluetoothAdapter.isEnabled()) {
            BluetoothAdapter.getDefaultAdapter().enable();
            Toast.makeText(getActivity(), R.string.state_off, Toast.LENGTH_SHORT).show();
            getActivity();
        }
        mListener.onShowProgress();
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        mGatt = device.connectGatt(getActivity(), true, mCallback);
    }

    private BluetoothGattCallback mCallback = new BluetoothGattCallback() {
        double result[];
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss:SS", Locale.getDefault());

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            switch (newState) {
                case BluetoothGatt.STATE_CONNECTED:
                    // as soon as we're connected, discover services
                    mGatt.discoverServices();
                    break;
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            // as soon as services are discovered, acquire characteristic and try enabling
            mMovService = mGatt.getService(UUID.fromString("F000AA80-0451-4000-B000-000000000000"));
            mEnable = mMovService.getCharacteristic(UUID.fromString("F000AA82-0451-4000-B000-000000000000"));
            if (mEnable == null) {
                Toast.makeText(getActivity(), R.string.service_not_found, Toast.LENGTH_LONG).show();
                getActivity().finish();
            }


            mEnable.setValue(0b1000111000, BluetoothGattCharacteristic.FORMAT_UINT16, 0);
            mGatt.writeCharacteristic(mEnable);
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            if (characteristic == mEnable) {
                // if enable was successful, set the sensor period to the lowest value
                mPeriod = mMovService.getCharacteristic(UUID.fromString("F000AA83-0451-4000-B000-000000000000"));
                if (mPeriod == null) {
                    Toast.makeText(getActivity(), R.string.service_not_found, Toast.LENGTH_LONG).show();
                    getActivity().finish();
                }
                mPeriod.setValue(0x0A, BluetoothGattCharacteristic.FORMAT_UINT8, 0);
                mGatt.writeCharacteristic(mPeriod);
            } else if (characteristic == mPeriod) {
                // if setting sensor period was successful, start polling for sensor values
                mRead = mMovService.getCharacteristic(UUID.fromString("F000AA81-0451-4000-B000-000000000000"));
                if (mRead == null) {
                    Toast.makeText(getActivity(), R.string.characteristic_not_found, Toast.LENGTH_LONG).show();
                    getActivity().finish();
                }
                previousRead = Calendar.getInstance();
                mGatt.readCharacteristic(mRead);
                deviceConnected();
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicRead(gatt, characteristic, status);

            // convert raw byte array to G unit values for xyz axes
                result = representations.convertAccel(characteristic.getValue());
                if (mIsRecording) {
                    double X = result[0];
                    double Y = result[1];
                    double Z = result[2];
                    sensor fire = new sensor(X, Y, Z);//here
                  databaseReference.child("Accelerometer").setValue(fire);








                    L1 = mloc.getLatitude();
                    L2 = mloc.getLongitude();
                locAddress = mloc.getAddress();
//locationCon nl= new locationCon(L1,L2,locAddress);
              //  databaseReference.child("latitude").setValue(L1);
              //  databaseReference.child("longitude").setValue(L2);
              //  databaseReference.child("address").setValue(locAddress);//
//
             databaseReference.child("Location").child("latitude").setValue(L1);
                databaseReference.child("Location").child("longitude").setValue(L2);
                databaseReference.child("Location").child("address").setValue(locAddress);
            }
            getActivity().runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    if (isAdded()) {

                        // update current acceleration readings
                        mXAxis.setText(String.format(getString(R.string.xAxis), Math.abs(result[0])));
                        mYAxis.setText(String.format(getString(R.string.yAxis), Math.abs(result[1])));
                        mZAxis.setText(String.format(getString(R.string.zAxis), Math.abs(result[2])));
                        mXAxis.setTextColor(ContextCompat.getColor(getActivity(), result[0] < 0 ? R.color.red : R.color.green));
                        mYAxis.setTextColor(ContextCompat.getColor(getActivity(), result[1] < 0 ? R.color.red : R.color.green));
                        mZAxis.setTextColor(ContextCompat.getColor(getActivity(), result[2] < 0 ? R.color.red : R.color.green));
                        lat.setText(String.format(getString(R.string.Lat),mloc.getLatitude()));
                        lon.setText(String.format(getString(R.string.Lon),mloc.getLongitude()));
                        textAddress.setText(mloc.getAddress());

                    }
                }
            });
            // poll for next values
            previousRead = Calendar.getInstance();
            mGatt.readCharacteristic(mRead);
        }
    };

 //   @Override
//    public void onClick(View view) {//can go soon enough
//        switch (view.getId()) {
//            case R.id.bStart:
//                startRecording();
//                break;
//            case R.id.bStop:
//                stopRecording();
//                break;
//            case R.id.bExport://sending it off
//                try {
//                    // create and write output file in cache directory
//                    File outputFile = new File(getActivity().getCacheDir(), "recording" + new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(Calendar.getInstance().getTime()) + ".json");
//                    OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(outputFile));
//                   // writer.write(representations.recordingToCSV(mRecording));
//                    writer.write(representations.recordingToJSON(mRecording));
//                    writer.close();
//
//                    // get Uri from FileProvider
//                    Uri contentUri = FileProvider.getUriForFile(getActivity(), "com.example.aal_assistant.fileprovider", outputFile);
//
//                    // create sharing intent
//                    Intent shareIntent = new Intent();
//                    shareIntent.setAction(Intent.ACTION_SEND);
//                    // temp permission for receiving app to read this file
//                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//                    shareIntent.setType("text/json");
//                    shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
//                    startActivity(Intent.createChooser(shareIntent, "Choose an app"));
//                } catch (IOException e) {
//                    Toast.makeText(getActivity(), R.string.error_file, Toast.LENGTH_SHORT).show();
//                }
//                break;
//        }
//    }

    /**
     * Called when the device has been fully connected.
     */
    private void deviceConnected() {
        mListener.onHideProgress();
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
              //  mStart.setEnabled(true);
            }
        });

        // start connection watcher thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean hasConnection = true;
                while (hasConnection) {
                    long diff = Calendar.getInstance().getTimeInMillis() - previousRead.getTimeInMillis();
                    if (diff > 2000) {
                        hasConnection = false;
                        //Toast.makeText(getContext(), R.string.connection_lost, Toast.LENGTH_LONG).show();
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                //Toast.makeText(getContext(), R.string.connection_lost, Toast.LENGTH_LONG).show();
                                // deviceDisconnected();
                            }
                        });
                    }
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    /**
     * Called when the device should be disconnected.
     */
    private void deviceDisconnected() {
       // stopRecording();
      //  mStart.setEnabled(false);
        if (mGatt != null) mGatt.disconnect();
    }

    /**
     * Starts the recording and updates the UI to reflect that.
     */
    private void startRecording() {
        // update UI
        mStart.setEnabled(false);
        mExport.setEnabled(false);
        mStop.setEnabled(true);
     //   mIsRecording = true;
       // mIsRecording = false;
      //  mMax.setVisibility(View.INVISIBLE);

        mRecording = new ArrayList<>();
        recordingStart = Calendar.getInstance();
    }

    /**
     * Stops the recording and updates the UI to reflect that.
     */
    private void stopRecording() {
        if (mIsRecording) {
            // update UI
            mStop.setEnabled(false);
            mStart.setEnabled(true);
            mExport.setEnabled(true);
            mIsRecording = false;
           // mIsRecording = true;

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View layout = inflater.inflate(R.layout.accelerometer_fragment, container, false);
        mXAxis = (TextView) layout.findViewById(R.id.tvXAxis);
        mYAxis = (TextView) layout.findViewById(R.id.tvYAxis);
        mZAxis = (TextView) layout.findViewById(R.id.tvZAxis);
        lat = (TextView) layout.findViewById(R.id.latitude);
        lon = (TextView) layout.findViewById(R.id.longitude);
        textAddress = (TextView) layout.findViewById(R.id.StringAdd);
//        mMax = (TextView) layout.findViewById(R.id.tvMax);
//        mStart = (Button) layout.findViewById(R.id.bStart);
//        mStop = (Button) layout.findViewById(R.id.bStop);
//        mExport = (Button) layout.findViewById(R.id.bExport);
//        double la = mloc.getLatitude();
//        double lo = mloc.getLongitude();
//        String  lat = Double.toString(la);
//        String lon = Double.toString(lo);
//        mStart.setOnClickListener(this);
//        mStop.setOnClickListener(this);
//        mExport.setOnClickListener(this);
        return layout;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof inter.updateAction) {
            mListener = (inter.updateAction) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnStatusListener");
        }
    }

}

